Manual Installation
------------------------------------

1) Unpack the files wherever you like
2) Copy mcu_lcd.TTF into Windows\Fonts folder